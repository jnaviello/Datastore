#Refactored Google's Guest Book Sample Code 

The code has been refactored to create Wall Posts instead of Guest Book posts in order to make the concept more relevent and more meaningful.

Extra comments have been made in order to help the reader understand every line of the code.

This full code will not successfully run though. The reader will have to add in additional code to collect information and write out information from the database to the website.
